package top.miaodou.Demo2;

import java.util.Date;

import com.opensymphony.xwork2.ActionSupport;

import top.miaodou.domain.User;
/**
 * 数据封装的方式一：提供属性的set方法的方式
 * */
public class UserAction2 extends ActionSupport{
	//提供了对应的属性
	private User user;
	
	
	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	@Override
	public String execute() throws Exception {
		System.out.println(user);
		return NONE;
	}

}
