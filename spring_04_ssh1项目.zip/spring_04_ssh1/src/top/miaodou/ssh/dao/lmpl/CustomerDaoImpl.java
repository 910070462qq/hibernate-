package top.miaodou.ssh.dao.lmpl;


import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.ssh.dao.CustomerDao;
import top.miaodou.ssh.domain.Customer;
/**
 * 客户管理的DAO层的实现类
 * */
public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao {

	@Override
	public void save(Customer customer) {
		System.out.println("DAO中的Service方法执行了。。。");
		//在DAO中使用HIbernate的模板完成保存操作
		this.getHibernateTemplate().save(customer);
	}

	@Override
	public void update(Customer customer) {
		this.getHibernateTemplate().update(customer);
	}

	@Override
	public void delete(Customer customer) {
		this.getHibernateTemplate().delete(customer);
	}

	@Override
	public Customer findById(Long cust_id) {
		
//		return this.getHibernateTemplate().get(Customer.class, cust_id);
		return this.getHibernateTemplate().load(Customer.class, cust_id);
	}

	@Override
	public List<Customer> findAllByHQL() {
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().find("from Customer");
		return list;
	}

	@Override
	public List<Customer> findAllByQBC() {
		DetachedCriteria criteria = DetachedCriteria.forClass(Customer.class);
		List<Customer> list = (List<Customer>) this.getHibernateTemplate().findByCriteria(criteria);
		return list;
	}

	@Override
	public List<Customer> findAllByNameQuery() {

		return (List<Customer>) this.getHibernateTemplate().findByNamedQuery("queryAll");
	}



}
