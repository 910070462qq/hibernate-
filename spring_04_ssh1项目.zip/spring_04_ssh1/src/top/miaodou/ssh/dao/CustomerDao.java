package top.miaodou.ssh.dao;

import java.util.List;

import top.miaodou.ssh.domain.Customer;

/**
 * 客户管理的DAO层的接口
 * */
public interface CustomerDao {

	void save(Customer customer);

	void update(Customer customer);
	
	void delete(Customer customer);
	
	Customer findById(Long cust_id);
	
	List<Customer> findAllByHQL();
	
	List<Customer> findAllByQBC();
	
	List<Customer> findAllByNameQuery();
}
