package top.miaodou.ssh.service.impl;

import java.util.List;

import org.springframework.orm.hibernate5.support.OpenSessionInViewFilter;
import org.springframework.transaction.annotation.Transactional;

import top.miaodou.ssh.dao.CustomerDao;
import top.miaodou.ssh.domain.Customer;
import top.miaodou.ssh.service.CustomerService;
/**
 * 客户管理的业务层的实现类
 * */
@Transactional
public class CustomerServiceImpl implements CustomerService {

	//注入DAO
	private  CustomerDao customerDao;

	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}



	@Override
	public void save(Customer customer) {
		System.out.println("Service中的save方法执行了。。。");
		customerDao.save(customer);
	}



	@Override
	public void update(Customer customer) {
		customerDao.update(customer);
	}



	@Override
	public void delete(Customer customer) {
		customerDao.delete(customer);
	}



	@Override
	public Customer findById(Long cust_id) {
		return customerDao.findById(cust_id);
	}



	@Override
	public List<Customer> findAllByHQl() {
		return customerDao.findAllByHQL();
	}



	@Override
	public List<Customer> findAllByQBC() {
		return customerDao.findAllByQBC();
	}



	@Override
	public List<Customer> findAllByNameQuery() {

		return customerDao.findAllByNameQuery();
	}

}
