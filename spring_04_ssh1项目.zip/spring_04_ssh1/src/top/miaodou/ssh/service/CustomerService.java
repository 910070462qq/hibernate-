package top.miaodou.ssh.service;

import java.util.List;

import top.miaodou.ssh.domain.Customer;

/**
 * 客户管理的业务层的接口
 * */
public interface CustomerService {

	void save(Customer customer);
	void update(Customer customer);
	void delete(Customer customer);
	Customer findById(Long cust_id);
	List<Customer> findAllByHQl();
	List<Customer> findAllByQBC();
	List<Customer> findAllByNameQuery();
	
}
