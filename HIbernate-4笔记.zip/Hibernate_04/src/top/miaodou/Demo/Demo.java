package top.miaodou.Demo;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.domain.Customer;
import top.miaodou.domain.LinkMan;
import top.miaodou.hibernate.Utils.HibernateUtils;

/**
 * HQL的查询方式的测试类
 * */
public class Demo {
	
	@Test
	/**
	 * 初始化数据
	 * */
	public void Demo01(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//创建一个客户
		Customer customer = new Customer();
		customer.setCust_name("赵六");
		
		for (int i = 0; i < 10; i++) {
			LinkMan linkMan = new LinkMan();
			linkMan.setLkm_name("李伟"+i);
			linkMan.setCustomer(customer);
			
			customer.getLinkMans().add(linkMan);
			session.save(linkMan);
		}
		session.save(customer);
		
		tx.commit();
	}
	
	@Test
	/**
	 * HQL的简单查询
	 * */
	public void Demo02(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		Query query = session.createQuery("from Customer");
		List<Customer> list = query.list();
		
		//这种别名查询也是可以的
//		Query query = session.createQuery("select c from Customer c");
//		List<Customer> list = query.list();
		
//		//sql中支持*号的写法：select * from cst_customer;但是在HQL中不支持*号的写法
//		Query query = session.createQuery("select * from Customer");
//		List<Customer> list = query.list();
		
		for (Customer customer : list) {
			System.out.println(customer);
		}
		
		tx.commit();
	}
	
	@Test
	/**
	 * 排序查询
	 * */
	public void Demo03(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		//默认的培训，升序
//		List<Customer> list = session.createQuery("from Customer").list();
		
		//设置降序排序,升序使用asc，降序desc
		List<Customer> list = session.createQuery("from Customer order by cust_id desc").list();
		
		
		for (Customer customer : list) {
			System.out.println(customer);
		}
		
		tx.commit();
	}
	
	
	@Test
	/**
	 * 条件查询
	 * */
	public void Demo04(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();

		//条件的查询
		//1.位置的绑定：根据参数的位置进行绑定。
		//一个条件
		/*Query query = session.createQuery("from Customer where cust_name = ?");
		query.setParameter(0, "李四");
		List<Customer> list = query.list();*/
		
		/*多个条件
		Query query = session.createQuery("from Customer where cust_name like ? and cust_source like ?");
		query.setParameter(0, "李%");
		query.setParameter(1, "爱情%");
		List<Customer> list = query.list();*/
		
		//按名称绑定
		Query query = session.createQuery("from Customer where cust_name like :aaa and cust_source = :bbb");
		query.setParameter("aaa", "王%");
		query.setParameter("bbb", "乡村爱情");
		List<Customer> list = query.list();
		
		for (Customer customer : list) {
			System.out.println(customer);
		}
		
		tx.commit();
	}
	
	@Test
	/**
	 * 投影查询
	 * */
	public void Demo05(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();

		//条件的查询
		//1.位置的绑定：根据参数的位置进行绑定。
		//一个属性
		/*Query query = session.createQuery("select c.cust_name from Customer c");
		List<Object> list = query.list();*/
		
		//多个属性
		/*Query query = session.createQuery("select c.cust_name,c.cust_source from Customer c");
		List<Object[]> list = query.list();*/
		
		//查询多个属性，并封装到对象中
		Query query = session.createQuery("select new Customer(cust_name,cust_source) from Customer");
		List<Customer> list = query.list();
		
		for (Customer customer : list) {
			System.out.println(customer);
		}
		
		tx.commit();
	}
	
	@Test
	/**
	 * 分页查询
	 * */
	public void Demo06(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();

		//分页查询
		Query query = session.createQuery("from LinkMan");
		//从哪一条开始
		query.setFirstResult(10);
		//从开始的第一条连续查多少条
		query.setMaxResults(10);
		List<LinkMan> list = query.list();
		
		for (LinkMan linkMan : list) {
			System.out.println(linkMan);
		}
		
		tx.commit();
	}
	
	@Test
	/**
	 * 分页统计查询
	 * */
	public void Demo07(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();

		//聚合函数的使用：count(),max(),min(),avg(),sum()
		//分组统计
		List<Object[]> list = session.createQuery("select cust_source,count(*) from Customer group by cust_source having count(*) >= 2").list();
		for (Object[] objects : list) {
			System.out.println(Arrays.toString(objects));
		}
		
		
		
		
		tx.commit();
	}
	
	@Test
	/**
	 * HQL的多表的查询
	 * */
	public void Demo08(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();

		/*//SQL:select * from cst_customer c inner join cst_linkman l on c.cust_id = l.lkm_cust_id;
		//HQL:内连接查询
		List<Object[]> list = session.createQuery("from Customer c inner join c.linkMans").list();
		
		for (Object[] objects : list) {
			System.out.println(Arrays.toString(objects));
		}*/
		
		//HQL:迫切内连接其实就这普通的内连接inner join后添加一个关键字fetch。
		List<Customer> list = session.createQuery("select distinct c from Customer c inner join c.linkMans").list();
												//distinct:去除重复的对象
		for (Customer customer : list) {
			System.out.println(customer);
		}
		
		tx.commit();
	}
}
