package top.miaodou.Demo2;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.domain.Customer;
import top.miaodou.domain.LinkMan;
import top.miaodou.hibernate.Utils.HibernateUtils;

/**
 * 在<set>上的fetch和lazy
 * */
public class Demo02 {
	
	@Test
	/**
	 * 默认情况
	 * */
	public void Demo(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//查询一号客户
		Customer customer= session.get(Customer.class, 1l);
		System.out.println(customer.getCust_name());//只会发送一条查询客户的信息
		//查看1号客户的每个联系人的信息
		for (LinkMan linkMan : customer.getLinkMans()) {//发送一条查询联系人的SQL语句
			System.out.println(linkMan.getLkm_name());
		}
		
		
		tx.commit();
	}
	
	@Test
	/**
	 * 设置fetch="select" lazy="true"
	 * */
	public void Demo01(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//查询一号客户
		Customer customer= session.get(Customer.class, 1l);
		System.out.println(customer.getCust_name());//只会发送一条查询客户的信息
		//查看1号客户的每个联系人的信息
		for (LinkMan linkMan : customer.getLinkMans()) {//发送一条根据客户ID查询联系人的SQL语句
			System.out.println(linkMan.getLkm_name());
		}
		
		
		tx.commit();
	}
	
	@Test
	/**
	 * 设置fetch="select" lazy="false"
	 * */
	public void Demo02(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//查询一号客户
		Customer customer= session.get(Customer.class, 1l);
		System.out.println(customer.getCust_name());//发送两条SQL语句：查询客户的名称，查询客户关联联系人
		//查看1号客户的每个联系人的信息
		for (LinkMan linkMan : customer.getLinkMans()) {//发送一条根据客户ID查询联系人的SQL语句
			System.out.println(linkMan.getLkm_name());
		}
		
		
		tx.commit();
	}
	
	@Test
	/**
	 * 设置fetch="select" lazy="extra"：及其懒惰的时候
	 * */
	public void Demo03(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//查询一号客户
		Customer customer= session.get(Customer.class, 1l);
		System.out.println(customer.getCust_name());//发送条查询1号客户的SQL的语句

		System.out.println(customer.getLinkMans().size());//发送一条select count() from
		
		tx.commit();
	}
	
	
	@Test
	/**
	 * 设置fetch="join" lazy="true"
	 * */
	public void Demo04(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//查询一号客户
		Customer customer= session.get(Customer.class, 1l);
		System.out.println(customer.getCust_name());//发送1条迫切左外连接来查询记录

		System.out.println(customer.getLinkMans().size());//不发生，已经查询到
		
		tx.commit();
	}
	
	@Test
	/**
	 * 设置fetch="subselect" lazy="true"
	 * */
	public void Demo05(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		List<Customer> list= session.createQuery("from Customer").list();
		for (Customer customer : list) {
			System.out.println(customer.getCust_name());//发送一条查询客户的语句
			System.out.println(customer.getLinkMans().size());//发送一条子查询数量的信息
		}
		
		
		tx.commit();
	}
	
	@Test
	/**
	 * 设置fetch="subselect" lazy="false"
	 * */
	public void Demo06(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		List<Customer> list= session.createQuery("from Customer").list();
		for (Customer customer : list) {
			System.out.println(customer.getCust_name());//发送一条查询客户的语句，发送一条子查询数量的信息一起查
			System.out.println(customer.getLinkMans().size());
		}
		
		
		tx.commit();
	}
}
