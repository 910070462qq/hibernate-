package top.miaodou.Demo2;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.domain.Customer;
import top.miaodou.hibernate.Utils.HibernateUtils;

/**
 * Hibernate的延迟加载
 * */
public class Demo {

	@Test
	/**
	 * 类级别的延迟加载
	 * 在<class>的标签上配置的lazy
	 * */
	public void demo1(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		Customer load = session.load(Customer.class, 1l);
		Hibernate.initialize(load);
		System.out.println(load);
		
		tx.commit();
	}
}
