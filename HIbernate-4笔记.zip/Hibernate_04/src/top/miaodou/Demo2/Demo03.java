package top.miaodou.Demo2;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.domain.LinkMan;
import top.miaodou.hibernate.Utils.HibernateUtils;

/**
 * many-to-one的fetch和lazy测试
 * */
public class Demo03 {

	@Test
	/**
	 * 默认值
	 * */
	public void demo01(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		LinkMan linkMan = session.get(LinkMan.class, 1l);//发送一条查询联系人的语句
		System.out.println(linkMan.getLkm_name());
		System.out.println(linkMan.getCustomer().getCust_name());//根据外键又去查询一边
		
		
		tx.commit();
	}
	
	
	@Test
	/**
	 * <many-to-one name="Customer" fetch="select" lazy="proxy"
	 * */
	public void demo02(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		LinkMan linkMan = session.get(LinkMan.class, 1l);//发送一条查询联系人的语句
		System.out.println(linkMan.getLkm_name());
		System.out.println(linkMan.getCustomer().getCust_name());//根据外键又去查询一边
		
		
		tx.commit();
	}
	
	@Test
	/**
	 * <many-to-one name="Customer" fetch="select" lazy="false"
	 * */
	public void demo03(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		LinkMan linkMan = session.get(LinkMan.class, 1l);//直接发送俩条语句，联系人的和客户的都会查询
		System.out.println(linkMan.getLkm_name());
		System.out.println(linkMan.getCustomer().getCust_name());
		
		
		tx.commit();
	}
	
	@Test
	/**
	 * <many-to-one name="Customer" fetch="join" lazy="false=失效了"
	 * */
	public void demo04(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		LinkMan linkMan = session.get(LinkMan.class, 1l);//发送一条迫切左外连接语句，联系人关联客户的查询
		System.out.println(linkMan.getLkm_name());
		System.out.println(linkMan.getCustomer().getCust_name());
		
		
		tx.commit();
	}
}
