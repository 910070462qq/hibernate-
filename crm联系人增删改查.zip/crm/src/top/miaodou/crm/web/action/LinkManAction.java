package top.miaodou.crm.web.action;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import top.miaodou.crm.domain.Customer;
import top.miaodou.crm.domain.LinkMan;
import top.miaodou.crm.domain.PageBean;
import top.miaodou.crm.service.CustomerService;
import top.miaodou.crm.service.LinkManService;

public class LinkManAction extends ActionSupport implements ModelDriven<LinkMan>{
	// 模型驱动使用的对象
		private LinkMan linkMan = new LinkMan();

		@Override
		public LinkMan getModel() {
			return linkMan;
		}

		// 注入service
		private LinkManService linkManService;

		public void setLinkManService(LinkManService linkManService) {
			this.linkManService = linkManService;
		}

		//注入客户管理的Service
		private CustomerService customerService;
		public void setCustomerService(CustomerService customerService) {
			this.customerService = customerService;
		}

		
		// 分页的参数
		private Integer currPage = 1;
		private Integer pageSize = 3;

		public void setCurrPage(Integer currPage) {
			if (currPage == null) {
				currPage = 1;
			}
			this.currPage = currPage;
		}

		public void setPageSize(Integer pageSize) {
			if (pageSize == null) {
				pageSize = 3;
			}
			this.pageSize = pageSize;
		}

		/**
		 * 查询联系人列表的Action，并进行分页
		 */
		public String findAll() {
			// 创建离线条件查询：
			DetachedCriteria detachedCriteria = DetachedCriteria.forClass(LinkMan.class);
			// 设置条件
			if(linkMan.getLkm_name() != null){
				//设置按名称查询的条件
				detachedCriteria.add(Restrictions.like("lkm_name", "%"+linkMan.getLkm_name()+"%"));
			}
			//设置性别的条件
			if(linkMan.getLkm_gender() != null && !"".equals(linkMan.getLkm_gender())){
				//设置按照性别查询的条件：
				detachedCriteria.add(Restrictions.eq("lkm_gender", linkMan.getLkm_gender()));
			}
			// 调用业务层
			PageBean<LinkMan> pageBean = linkManService.findAll(detachedCriteria, currPage, pageSize);
			// 将查询到的pageBean往值栈里面放
			ActionContext.getContext().getValueStack().push(pageBean);
			return "findAll";
		}
		
		/**
		 * 跳转到添加页面的方法saveUI
		 * */
		public String saveUI(){
			//同步进行查询：查询所有客户
			List<Customer> list = customerService.findAll();
			//将list集合保存值栈中：
			ActionContext.getContext().getValueStack().set("list", list);
			return "saveUI";
		}

		/**
		 * 保存客户的方法：save
		 * */
		public String save(){
			//调用业务层保存联系人
			linkManService.save(linkMan);
			return "saveSuccess";
		}
		
		/**
		 * 跳转到编辑页面的方法：edit
		 * */
		public String edit(){
			//查询某个联系人，查询所有客户。
			//查询所有客户
			List<Customer> list = customerService.findAll();
			//根据id查询联系人：
			linkMan = linkManService.findById(linkMan.getLkm_id());
			//将list和linkMan的对象带到页面上
			ActionContext.getContext().getValueStack().set("list", list);
			//将对象的值存入到值栈：
			ActionContext.getContext().getValueStack().push(linkMan);		
			return "editSuccess";
		}
		
		/**
		 * 修改联系人的方法：update
		 * */
		public String update(){
			//调用业务层：
			linkManService.update(linkMan);
			return "updateSuccess";
		}
		/**
		 * 删除联系人的方式：delete
		 * */
		public String delete(){
			//先查询，调用业务层
			linkMan = linkManService.findById(linkMan.getLkm_id());
			//删除联系人
			linkManService.delete(linkMan);
			return "deleteSuccess";
		}
		
}
