package top.miaodou.crm.service.impl;

import java.util.List;

import top.miaodou.crm.dao.BaseDictDao;
import top.miaodou.crm.domain.BaseDict;
import top.miaodou.crm.service.BaseDictService;
/**
 * 字典的业务层的实现类
 * */
public class BaseDictServiceImpl implements BaseDictService {
	//注入DAO
	private BaseDictDao baseDictDao;

	public void setBaseDictDao(BaseDictDao baseDictDao) {
		this.baseDictDao = baseDictDao;
	}

	@Override
	public List<BaseDict> finByTypeCode(String dict_type_code) {
		return baseDictDao.finByTypeCode(dict_type_code);
	}	
}
