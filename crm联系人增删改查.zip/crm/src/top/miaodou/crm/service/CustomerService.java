package top.miaodou.crm.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import top.miaodou.crm.domain.Customer;
import top.miaodou.crm.domain.PageBean;

/**
 * 客户管理的Service接口
 * */
public interface CustomerService {

	void save(Customer customer);

	PageBean<Customer> findByPage(DetachedCriteria detachedCriteria, Integer currPage,Integer pageSize);

	Customer findById(Long cust_id);

	void delete(Customer customer);

	void update(Customer customer);

	List<Customer> findAll();



	

	
}
