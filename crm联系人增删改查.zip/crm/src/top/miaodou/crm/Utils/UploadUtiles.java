package top.miaodou.crm.Utils;

import java.util.UUID;

/**
 * 文件上传的工具类:
 * 解决目录下文件名重复的问题
 * */
public class UploadUtiles {
	
	public static String getUuidFileName(String fileName){
		int idx = fileName.lastIndexOf(".");
		String extions = fileName.substring(idx);
		return UUID.randomUUID().toString().replace("-", "")+extions;		
	}
	
	/**
	 * 目录分离的方法
	 * */
	public static String getPath(String uuidFileName){
		
		int code = uuidFileName.hashCode();
		int d1 = code & 0xf;
		
		return null;
	}
	
	public static void main(String[] args) {
		System.out.println(getUuidFileName("aa.txt"));
	}
	
}
