package top.miaodou.crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.crm.dao.BaseDao;
import top.miaodou.crm.dao.LinkManDao;
import top.miaodou.crm.domain.Customer;
import top.miaodou.crm.domain.LinkMan;
/**
 * 联系人的DAO的实现类
 * */
public class LinkManDaoImpl extends BaseDaoimpl<LinkMan> implements LinkManDao {

	@Override
	//Dao中统计个数的方法
	public Integer findCount(DetachedCriteria detachedCriteria) {
		detachedCriteria.setProjection(Projections.rowCount());
		List<Long> list = (List<Long>) this.getHibernateTemplate().findByCriteria(detachedCriteria);
		if(list.size() > 0){
			return list.get(0).intValue();
		}
		return null;
	}

	@Override
	//DAO的分页查询
	public List<LinkMan> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize) {
		detachedCriteria.setProjection(null);
		List<LinkMan> list = (List<LinkMan>) this.getHibernateTemplate().findByCriteria(detachedCriteria,begin,pageSize);
		return list;
	}

	@Override
	//DAO中根据ID查询联系人的方法
	public LinkMan findById(Long lkm_id) {
		return this.getHibernateTemplate().get(LinkMan.class, lkm_id);
	}
}
