package top.miaodou.crm.dao.impl;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.crm.dao.BaseDao;
/**
 * 通用的DAO的实现类
 * */
public class BaseDaoimpl<T> extends HibernateDaoSupport implements BaseDao<T> {

	@Override
	public void save(T t) {
		this.getHibernateTemplate().save(t);
	}

	@Override
	public void update(T t) {
		this.getHibernateTemplate().update(t);
	}

	@Override
	public void delete(T t) {
		this.getHibernateTemplate().delete(t);
	}

}
