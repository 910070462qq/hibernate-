package top.miaodou.crm.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.crm.dao.BaseDictDao;
import top.miaodou.crm.domain.BaseDict;
/**
 * 字典DAO的实现类
 * */
public class BaseDictDaoImpl extends HibernateDaoSupport implements BaseDictDao {

	@Override
	//根据类型编码查询数据
	public List<BaseDict> finByTypeCode(String dict_type_code) {
		
		return (List<BaseDict>) this.getHibernateTemplate().find("from BaseDict where dict_type_code = ?", dict_type_code);
	}
}
