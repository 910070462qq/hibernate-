package top.miaodou.crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.crm.dao.CustomerDao;
import top.miaodou.crm.domain.Customer;
/**
 * 客户管理的DAO的实现类
 * */
public class CustomerDaoImpl extends BaseDaoimpl<Customer> implements CustomerDao {

	@Override
	//DAO带条件统计个数的方法
	public Integer findCount(DetachedCriteria detachedCriteria) {
		//select count(*) from xxx where 条件;
		detachedCriteria.setProjection(Projections.rowCount());
		List<Long> list = (List<Long>) this.getHibernateTemplate().findByCriteria(detachedCriteria);
		if(list.size() > 0){
			return list.get(0).intValue();
		}
		return null;
	}

	@Override
	//DAO分页查询客户的方法
	public List<Customer> finByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize) {
		detachedCriteria.setProjection(null);
		return (List<Customer>) this.getHibernateTemplate().findByCriteria(detachedCriteria,begin,pageSize);
	}

	@Override
	//根据id查询客户的方法
	public Customer findById(Long cust_id) {

		return this.getHibernateTemplate().get(Customer.class, cust_id);
	}


	@Override
	//DAO查询所有客户的方法
	public List<Customer> findAll() {
		
		return (List<Customer>) this.getHibernateTemplate().find("from Customer");
	}

}
