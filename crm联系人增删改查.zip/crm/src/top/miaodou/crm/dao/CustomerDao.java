package top.miaodou.crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import top.miaodou.crm.domain.Customer;

/**
 * 客户管理的DAO
 * */
public interface CustomerDao extends BaseDao<Customer>{

	Integer findCount(DetachedCriteria detachedCriteria);

	List<Customer> finByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize);

	Customer findById(Long cust_id);


	List<Customer> findAll();

}
