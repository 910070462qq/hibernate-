package top.miaodou.crm.dao;

import java.util.List;

import top.miaodou.crm.domain.BaseDict;

/**
 * 字典DAO的接口
 * */
public interface BaseDictDao {

	List<BaseDict> finByTypeCode(String dict_type_code);

}
