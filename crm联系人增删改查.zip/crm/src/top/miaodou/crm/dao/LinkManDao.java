package top.miaodou.crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import top.miaodou.crm.domain.Customer;
import top.miaodou.crm.domain.LinkMan;

/**
 * 联系人DAO的接口
 * */
public interface LinkManDao extends BaseDao<LinkMan>{

	Integer findCount(DetachedCriteria detachedCriteria);

	List<LinkMan> findByPage(DetachedCriteria detachedCriteria, Integer begin, Integer pageSize);

	LinkMan findById(Long lkm_id);

}
