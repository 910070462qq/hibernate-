package top.miaodou.tx.demo3;

/**
 * 转账的DAO的接口
 * */
public interface AccountDao {
	
	public void outMoney(String from,Double money);
	public void inMoney(String to,Double money);
}
