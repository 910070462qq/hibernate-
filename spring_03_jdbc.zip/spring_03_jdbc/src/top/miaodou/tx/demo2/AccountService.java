package top.miaodou.tx.demo2;

/**
 * 转账的业务层的接口
 * */
public interface AccountService {

	public void transfer(String from,String to,Double money);
}
