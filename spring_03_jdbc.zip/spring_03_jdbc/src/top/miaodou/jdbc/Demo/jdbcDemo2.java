package top.miaodou.jdbc.Demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import top.miaodou.jdbc.domain.Account;

//使用junit练习
@RunWith(SpringJUnit4ClassRunner.class)
//导入配置文件
@ContextConfiguration("classpath:applicationContext.xml")
public class jdbcDemo2 {
	
	//调用Spring里面管理的对象，就是xml里面的
	@Resource(name="jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	
	@Test
	//保存操作
	public void demo1(){
		jdbcTemplate.update("insert into account values(null,?,?)","大马猴",1111d);
	}
	
	@Test
	//修改操作
	public void demo2(){
		jdbcTemplate.update("update account set name=?,money=? where id=?","李四",20010d,5);
	}
	
	@Test
	//删除操作
	public void demo3(){
		jdbcTemplate.update("delete from account where id=?",5);
	}
	
	@Test
	//查询操作，jdbc方式
	public void demo4(){													//返回类型
		String name = jdbcTemplate.queryForObject("select name from account where id = ?", String.class,3);
		System.out.println(name);
		
	}
	
	@Test
	//查询操作，查询个数方式
	public void demo5(){													//返回类型
		Long count = jdbcTemplate.queryForObject("select count(*) from account", Long.class);
		System.out.println(count);
		
	}
	@Test
	//封装到一个对象中
	public void demo6(){
		Account account = jdbcTemplate.queryForObject("select * from account where id =?", new MyRowMapper(), 3);
		System.out.println(account);
	
	}
	
	@Test
	//查询多条记录
	public void demo7(){
		List<Account> list = jdbcTemplate.query("select * from account", new MyRowMapper());
		for (Account account : list) {
			System.out.println(account);
		}
		
	}
	
	
	class MyRowMapper implements RowMapper<Account>{

		@Override
		public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
			Account account = new Account();
			account.setId(rs.getInt("id"));
			account.setName(rs.getString("name"));
			account.setMoney(rs.getDouble("money"));
			return account;
		}
		
	}
}
