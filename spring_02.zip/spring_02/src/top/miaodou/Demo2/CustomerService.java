package top.miaodou.Demo2;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service("customerService")
@Scope("prototype")
public class CustomerService {
	
	@PostConstruct		//相当于init-method
	public void init(){
		System.out.println("初始化了。。。。。。");
	}
	
	
	public void save(){
		System.out.println("执行了。。。。。");
	}
	
	@PreDestroy		//相当于destory-method
	public void destroy(){
		System.out.println("销毁了。。。。");
	}
}
