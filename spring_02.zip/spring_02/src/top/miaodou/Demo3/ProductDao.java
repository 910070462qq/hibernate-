package top.miaodou.Demo3;

public class ProductDao {

	public void save(){
		System.out.println("ProductDao执行了。。。");
		
	}
}
