package top.miaodou.Demo3;

public class OrderDao {

	public void save(){
		System.out.println("OrderDao执行了。。。");
		
	}
}
