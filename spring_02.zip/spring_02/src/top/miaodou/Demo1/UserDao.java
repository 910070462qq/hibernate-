package top.miaodou.Demo1;

public interface UserDao {
	public void save();
}
