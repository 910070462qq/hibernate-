package top.miaodou.Demo1;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * spring的IOC的注解开发的测试类
 * */
public class springDemo1 {
	
	@Test
	/**
	 * 测试方法
	 * */
	public void demo1(){
		UserDao userDao = new UserDaoImpl();
		
		userDao.save();
	
	}
	
	@Test
	//Spring的IOC的注解方式
	public void demo2(){
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		UserDao userDao = (UserDao) applicationContext.getBean("userDao");
		
		userDao.save();
	}
	
	
	@Test
	//Spring的IOC的注解方式
	public void demo3(){
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		UserService userService = (UserService) applicationContext.getBean("userService");
		
		userService.save();
	}
	
	
}
