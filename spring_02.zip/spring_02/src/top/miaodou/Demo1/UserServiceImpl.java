package top.miaodou.Demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("userService")//相当于<bean id="userService" calss="">
public class UserServiceImpl implements UserService{
	
	//注入DAO
	@Autowired
	@Qualifier(value="userDao")
	private UserDao userDao;
	
	@Override
	public void save() {
		userDao.save();
		System.out.println("UserServiceimpl执行了。。。。。");
		
	}

}
