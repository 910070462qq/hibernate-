package top.miaodou.Demo1;

public interface UserService {
	public void save();
}
