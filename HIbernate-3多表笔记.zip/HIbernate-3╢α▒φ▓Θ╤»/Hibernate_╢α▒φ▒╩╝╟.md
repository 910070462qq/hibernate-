					# 第1章Hibernate_day03笔记 #
###1.1上次课内容回顾

Hibernate的持久化类的编写规则

无参数构造
属性私有
属性尽量使用包装类
提供一个唯一OID与主键对应
不要使用final修饰

Hibernate的主键生成策略

	主键分类
		自然主键
		代理主键

	主键生成策略
		increment
		identity
		sequence
		uuid
		native
		assigned
		foreign

Hibernate的持久化类的三种状态

		瞬时态：没有唯一标识OID，没有被session管理
		持久态：有唯一标识OID，已经被session管理
		脱管态：有唯一标识OID，没有被session管理

状态转换：（了解）

Hibernate的一级缓存

	一级缓存：Hibernate优化手段，称为是session级别缓存。
	一级缓存：快照区

Hibernate的事务管理
	事务的回顾
	事务的概念
	事务的特性
	引发安全性问题
	安全性问题解决

Hibernate解决读问题

	配置设置隔离级别

Hibernate解决Service事务

	采用的是线程绑定的方式：

Hibernate的其他的API

	Query		：HQL 面向对象方式的查询。
	Criteria		：QBC 完成面向对象化。
	SQLQuery	：SQL查询

##1.2Hibernate的一对多关联映射

1.2.1数据库表与表之间的关系

1.2.1.1一对多关系

什么样关系属于一对多？

	一个部门对应多个员工，一个员工只能属于某一个部门。
	一个客户对应多个联系人，一个联系人只能属于某一个客户。

一对多的建表原则：
![icon](01.png)

1.2.1.3一对一关系（了解）

	什么样关系属于一对一？
	一个公司只能有一个注册地址，一个注册地址只能被一个公司注册。

一对一的建表原则：
![icon](02.png)

1.2.2Hibernate一对多的关系配置

1.2.2.1创建一个项目，引入相应jar包

1.2.2.2创建数据库和表

	CREATE TABLE `cst_customer` (
	  `cust_id` bigint(32) NOT NULL AUTO_INCREMENT COMMENT '客户编号(主键)',
	  `cust_name` varchar(32) NOT NULL COMMENT '客户名称(公司名称)',
	  `cust_source` varchar(32) DEFAULT NULL COMMENT '客户信息来源',
	  `cust_industry` varchar(32) DEFAULT NULL COMMENT '客户所属行业',
	  `cust_level` varchar(32) DEFAULT NULL COMMENT '客户级别',
	  `cust_phone` varchar(64) DEFAULT NULL COMMENT '固定电话',
	  `cust_mobile` varchar(16) DEFAULT NULL COMMENT '移动电话',
	  PRIMARY KEY (`cust_id`)
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
	

	CREATE TABLE `cst_linkman` (
	  `lkm_id` bigint(32) NOT NULL AUTO_INCREMENT COMMENT '联系人编号(主键)',
	  `lkm_name` varchar(16) DEFAULT NULL COMMENT '联系人姓名',
	  `lkm_cust_id` bigint(32) DEFAULT NULL COMMENT '客户id',
	  `lkm_gender` char(1) DEFAULT NULL COMMENT '联系人性别',
	  `lkm_phone` varchar(16) DEFAULT NULL COMMENT '联系人办公电话',
	  `lkm_mobile` varchar(16) DEFAULT NULL COMMENT '联系人手机',
	  `lkm_email` varchar(64) DEFAULT NULL COMMENT '联系人邮箱',
	  `lkm_qq` varchar(16) DEFAULT NULL COMMENT '联系人qq',
	  `lkm_position` varchar(16) DEFAULT NULL COMMENT '联系人职位',
	  `lkm_memo` varchar(512) DEFAULT NULL COMMENT '联系人备注',
	  PRIMARY KEY (`lkm_id`),
	  KEY `FK_cst_linkman_lkm_cust_id` (`lkm_cust_id`),
	  CONSTRAINT `FK_cst_linkman_lkm_cust_id` FOREIGN KEY (`lkm_cust_id`) REFERENCES `cst_customer` (`cust_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

1.2.2.3创建实体

一的一方的实体
	
	public class Customer {
	private Long cust_id;
	private String cust_name;
	private String cust_source;
	private String cust_industry;
	private String cust_level;
	private String cust_phone;
	private String cust_mobile;
	
	// 通过ORM方式表示：一个客户对应多个联系人。
	// 放置的多的一方的集合。Hibernate默认使用的是Set集合。
	private Set<LinkMan> linkMans = new HashSet<LinkMan>();

多的一方的实体
	
	public class LinkMan {
	private Long lkm_id;
	private String lkm_name;
	private String lkm_gender;
	private String lkm_phone;
	private String lkm_mobile;
	private String lkm_email;
	private String lkm_qq;
	private String lkm_position;
	private String lkm_memo;
	
	//通过ORM方式表示：一个联系人只能属于某一个客户。
	//放置的是一的一方对象。hibernate默认室友的是set集合
	private Customer customer;

1.2.2.4创建映射文件

多的一方的映射的创建
![icon](03.png)

一的一方的映射的创建
![icon](04.png)
1.2.2.5创建核心配置文件

1.2.2.6引入工具类

1.2.2.7编写测试类
![icon](05.png)

###1.2.3Hibernate的一对多相关操作


###1.2.3.1一对多关系只保存一边是否可以：
![icon](06.png)

1.2.3.2一对多的级联操作

什么叫做级联

	级联指的是，操作一个对象的时候，是否会同时操作其关联的对象。

级联是有方向性

	操作一的一方的时候，是否操作到多的一方
	操作多的一方的时候，是否操作到一的一方

1.2.3.3级联保存或更新

保存客户级联联系人
![icon](07.png)
![icon](08.png)

保存联系人级联客户
![icon](09.png)
![icon](10.png)

1.2.3.4测试对象的导航
![icon](11.png)

1.2.3.5级联删除

级联删除：

	删除一边的时候，同时将另一方的数据也一并删除。
删除客户级联删除联系人
![icon](12.png)

删除联系人级联删除客户（基本不用）
![icon](13.png)

1.2.3.6一对多设置了双向关联产生多余的SQL语句
![icon](14.png)

解决多余的SQL语句

	单向维护：
	使一方放弃外键维护权：
		一的一方放弃。在set上配置inverse=”true”
	一对多的关联查询的修改的时候。（CRM练习--）

1.2.3.7区分cascade和inverse
![icon](15.png)

##1.3Hibernate的多对多关联映射

1.3.1Hibernate多对多关系的配置

1.3.1.1创建表

用户表

	CREATE TABLE `sys_user` (
	  `user_id` bigint(32) NOT NULL AUTO_INCREMENT COMMENT '用户id',
	  `user_code` varchar(32) NOT NULL COMMENT '用户账号',
	  `user_name` varchar(64) NOT NULL COMMENT '用户名称',
	  `user_password` varchar(32) NOT NULL COMMENT '用户密码',
	  `user_state` char(1) NOT NULL COMMENT '1:正常,0:暂停',
	  PRIMARY KEY (`user_id`)
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
角色表

	CREATE TABLE `sys_role` (
	  `role_id` bigint(32) NOT NULL AUTO_INCREMENT,
	  `role_name` varchar(32) NOT NULL COMMENT '角色名称',
	  `role_memo` varchar(128) DEFAULT NULL COMMENT '备注',
	  PRIMARY KEY (`role_id`)
	) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

中间表

	CREATE TABLE `sys_user_role` (
	  `role_id` bigint(32) NOT NULL COMMENT '角色id',
	  `user_id` bigint(32) NOT NULL COMMENT '用户id',
	  PRIMARY KEY (`role_id`,`user_id`),
	  KEY `FK_user_role_user_id` (`user_id`),
	  CONSTRAINT `FK_user_role_role_id` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
	  CONSTRAINT `FK_user_role_user_id` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;

1.3.1.2创建实体

用户的实体
![icon](16.png)

角色的实体
![icon](17.png)

1.3.1.3创建映射

用户的映射
![icon](18.png)

角色的映射
![icon](19.png)

1.3.1.4编写测试类

![icon](20.png)

1.3.2Hibernate的多对多的操作

1.3.2.1只保存一边是否可以

![icon](21.png)

1.3.2.2多对多的级联保存或更新

保存用户级联保存角色
![icon](22.png)

保存角色级联保存用户
![icon](23.png)

1.3.2.3多对多的级联删除（基本用不上）

删除用户级联删除角色
![icon](24.png)

删除角色级联删除用户
![icon](25.png)

1.3.2.4多对多的其他的操作

给用户选择角色
![icon](26.png)

给用户改选角色
![icon](27.png)

给用户删除角色
![icon](28.png)