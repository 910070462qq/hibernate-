package top.miaodou.crm.service;

import java.util.List;

import top.miaodou.crm.pojo.Customer;
import top.miaodou.crm.pojo.QueryVo;
import top.miaodou.crm.utils.Page;

/**
 * 客户信息业务逻辑接口
 * */

public interface CustomerService {
	
	/**
	 * 根据查询条件，分页查询用户列表
	 * */
	Page<Customer> getCustomerByQueryVo(QueryVo vo);
	/**
	 * 跟据id查询用户信息
	 * @param id
	 * @return
	 */
	Customer getCustomerById(Integer id);
	
	/**
	 * 更新用户信息
	 * @param customer
	 */
	void updateCustomer(Customer customer);
	
	/**
	 * 删除用户信息
	 * @param id
	 */
	void deleteCustomer(Integer id);
}
