package top.miaodou.crm.mapper;

import java.util.List;

import top.miaodou.crm.pojo.BaseDict;

/**
 * 字典数据表持久化接口
 * */

public interface BaseDictMapper {

	/**
	 * 根据字典编码查询字典列表
	 * */
	List<BaseDict> getBaseDictByCode(String code);
}
