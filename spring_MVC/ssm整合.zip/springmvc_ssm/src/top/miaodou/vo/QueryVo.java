package top.miaodou.vo;

import top.miaodou.pojo.Items;

public class QueryVo {

	//商品对象
	private Items items;
	//订单对象
	//用户对象
	
	public Items getItems() {
		return items;
	}

	public void setItems(Items items) {
		this.items = items;
	}
	
	
}
