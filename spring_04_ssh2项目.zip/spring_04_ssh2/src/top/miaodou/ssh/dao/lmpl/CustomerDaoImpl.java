package top.miaodou.ssh.dao.lmpl;


import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.ssh.dao.CustomerDao;
import top.miaodou.ssh.domain.Customer;
/**
 * 客户管理的DAO层的实现类
 * */
public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao {

	@Override
	public void save(Customer customer) {
		System.out.println("DAO中的Service方法执行了。。。");
		//在DAO中使用HIbernate的模板完成保存操作
		this.getHibernateTemplate().save(customer);

	}

}
