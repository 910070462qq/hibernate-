package top.miaodou.ssh.dao;

import top.miaodou.ssh.domain.Customer;

/**
 * 客户管理的DAO层的接口
 * */
public interface CustomerDao {

	void save(Customer customer);

}
