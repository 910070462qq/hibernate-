package top.miaodou.demo3;

public interface ProductDao {
	
	public void save();
	public void update();
	public void find();
	public String delete();
}
