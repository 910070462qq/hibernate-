package top.miaodou.demo3;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * 切面类
 * */
public class MyAspectXML {
	/**
	 * 前置通知
	 * */
	public void checkPri(JoinPoint joinPoint){
		System.out.println("权限校验======="+joinPoint);
	}
	/**
	 * 后置通知
	 * */
	public void writeLog(Object result){//这个名字必须要去配置文件中的returning相同
		System.out.println("日志记录===="+result);
	}
	/**
	 * 性能监控
	 * @throws Throwable 
	 * */
	public Object around(ProceedingJoinPoint joinpoint) throws Throwable{
		System.out.println("环绕前通知======");
		Object obj = joinpoint.proceed();
		System.out.println("环绕后通知======");
		return obj;
		
	}
	/**
	 * 异常抛出通知
	 * */
	public void afterThrowing(Throwable es){
		System.out.println("异常抛出通知======"+es.getMessage());
	}
	/**
	 * 最终通知：相当于finally代码块内容
	 * */
	public void after(){
		System.out.println("最终通知====");
	}
	
}
