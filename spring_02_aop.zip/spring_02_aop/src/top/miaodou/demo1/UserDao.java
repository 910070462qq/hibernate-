package top.miaodou.demo1;

public interface UserDao {
	
	public void save();
	public void update();
	public void find();
	public void delete();
}
