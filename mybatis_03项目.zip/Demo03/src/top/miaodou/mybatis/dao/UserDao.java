package top.miaodou.mybatis.dao;

import java.util.List;

import top.miaodou.mybatis.pojo.User;
/**
 * 用户信息持久化的接口
 * */
public interface UserDao {
	/**
	 * 根据用户ID查询用户列表
	 * */
	User getUserById(Integer id);
	/**
	 * 根据用户名查找用户列表
	 * */
	List<User> getUserByUserName(String userName);
	/**
	 * 添加用户
	 * */
	void insertUser(User user);
	
	
}
