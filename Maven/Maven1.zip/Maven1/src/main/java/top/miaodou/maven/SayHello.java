package top.miaodou.maven;

public class SayHello {

	public String say(String name){
		
		return "hello,"+name;
	}
}
