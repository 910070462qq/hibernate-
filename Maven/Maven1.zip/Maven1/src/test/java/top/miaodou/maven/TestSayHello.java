package top.miaodou.maven;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSayHello {
	
	@Test
	public void testSayHello(){
		SayHello say = new SayHello();
		String result = say.say("张三");
		assertEquals("hello,张三",result);
	}
}
