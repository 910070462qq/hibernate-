package top.miaodou.maven;

import static org.junit.Assert.*;

import org.junit.Test;

import top.miaodou.maven2.SayHelloTime;

public class TestSayHelloTime {

	@Test
	public void testSayHelloTime(){
		SayHelloTime say = new SayHelloTime();
		String result = say.sayTime("morning");
		assertEquals("hello,张三,morning",result);
	}
}
