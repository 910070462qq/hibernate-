package top.miaodou.maven2;

import top.miaodou.maven.SayHello;

public class SayHelloTime {
	
	public String sayTime(String name){
		
		SayHello hello = new SayHello();
		
		return hello.say("张三"+","+name);
	}
}
