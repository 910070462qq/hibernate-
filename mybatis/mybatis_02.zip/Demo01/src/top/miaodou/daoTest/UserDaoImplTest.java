package top.miaodou.daoTest;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.List;

import org.junit.Test;

import top.miaodou.dao.UserDao;
import top.miaodou.dao.impl.UserDaoImpl;
import top.miaodou.pojo.User;

public class UserDaoImplTest {

	@Test
	public void testGetUserById() {
		UserDao userDao = new UserDaoImpl();
		User user = userDao.getUserById(30);
		System.out.println(user);
	}

	@Test
	public void testGetUserByUserName() {
		UserDao userDao = new UserDaoImpl();
		List<User> list = userDao.getUserByUserName("张");
		for (User user : list) {
			System.out.println(user);
		}
	}
	@Test
	public void testInsertUser() {
		UserDao userDao = new UserDaoImpl();
		User user = new User();
		user.setUsername("李修好");
		user.setSex("2");
		user.setBirthday(new Date());
		user.setAddress("六安金寨");
		userDao.insertUser(user);
		
		
	}

}
