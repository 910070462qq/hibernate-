package top.miaodou.test;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import top.miaodou.pojo.User;
import top.miaodou.utils.sqlSessionFactoryUtils;

public class MybatisTest {

	@Test
	public void testGetUserById() throws Exception{
		//先去加载配置文件，，创建这个对象
		SqlSessionFactoryBuilder ssfb = new SqlSessionFactoryBuilder();
		//创建一个核心配置文件的输入流
		InputStream inputStream = Resources.getResourceAsStream("SqlMapConflg.xml");
		//通过输入流创建SqlSessionFactory对象
		SqlSessionFactory sqlSessionFactory = ssfb.build(inputStream);
		//创建SqlSession对象
		SqlSession sqlSession = sqlSessionFactory.openSession();
		//执行查询,参数一：sql id  参数二：传入的参数
		User user = sqlSession.selectOne("user.getUserById",1);
		//输出结果
		System.out.println(user.toString());
		//释放资源
		sqlSession.close();
	}
	
	@Test
	public void testGetUserByUserName(){
		//获取SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = sqlSessionFactoryUtils.getSqlSessionFactory();
		//获取SqlSession		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		//执行查询，返回集合
//		List<User> list =sqlSession.selectList("getUserByUserName", "%张%");
		List<User> list =sqlSession.selectList("getUserByUserName", "张");

		//遍历输出结果
		for (User user : list) {
			System.out.println(user);
		}
		//释放资源
		sqlSession.close();
	} 
	
	@Test
	public void testInsertUser(){
		//获取SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = sqlSessionFactoryUtils.getSqlSessionFactory();
		//获取SqlSession		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		//执行查询，返回集合

		User user = new User();
		user.setUsername("张三");
		user.setSex("1");
		user.setBirthday(new Date());
		user.setAddress("合肥");
		sqlSession.insert("user.insertUser", user);
		
		System.out.println(user);
		
		sqlSession.commit();
		
		//释放资源
		sqlSession.close();
	} 
	
	@Test
	public void testUpdateUser(){
		//获取SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = sqlSessionFactoryUtils.getSqlSessionFactory();
		//获取SqlSession		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		//执行查询，返回集合
		User user = new User();
		user.setId(26);
		user.setUsername("王六");
		sqlSession.insert("user.updateUser", user);
		
		sqlSession.commit();
		
		//释放资源
		sqlSession.close();
	} 
	
	
	@Test
	public void testInsertUserUUid(){
		//获取SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = sqlSessionFactoryUtils.getSqlSessionFactory();
		//获取SqlSession		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		//执行查询，返回集合

		User user = new User();
		user.setUsername("张三5");
		user.setSex("1");
		user.setBirthday(new Date());
		user.setAddress("合肥");
		sqlSession.update("user.insertUserUuid", user);
		
		System.out.println(user);
		
		sqlSession.commit();
		
		//释放资源
		sqlSession.close();
	} 
	
	
	@Test
	public void testDeleteUser(){
		//获取SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = sqlSessionFactoryUtils.getSqlSessionFactory();
		//获取SqlSession		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		//执行查询，返回集合
		sqlSession.delete("user.deleteUser",27);
		
		sqlSession.commit();
		
		//释放资源
		sqlSession.close();
	} 
	
	
	
	
	
	
	
}
