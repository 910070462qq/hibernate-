package top.miaodou.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import top.miaodou.dao.UserDao;
import top.miaodou.pojo.User;
import top.miaodou.utils.sqlSessionFactoryUtils;
/**
 * 用户信息持久化实现
 * */
public class UserDaoImpl implements UserDao {

	@Override
	public User getUserById(Integer id) {
		 SqlSession sqlsession = sqlSessionFactoryUtils.getSqlSessionFactory().openSession();
		 User user = sqlsession.selectOne("user.getUserById",id);
		 sqlsession.close();
		 return user;
	}

	@Override
	public List<User> getUserByUserName(String userName) {
		SqlSession sqlsession = sqlSessionFactoryUtils.getSqlSessionFactory().openSession();
		List<User> list = sqlsession.selectList("user.getUserByUserName", userName);
		sqlsession.close();
		return list;
	}

	@Override
	public void insertUser(User user) {
		SqlSession sqlsession = sqlSessionFactoryUtils.getSqlSessionFactory().openSession(true);
		sqlsession.insert("user.insertUser",user);
//		sqlsession.commit();;
		sqlsession.close();
	}

}
