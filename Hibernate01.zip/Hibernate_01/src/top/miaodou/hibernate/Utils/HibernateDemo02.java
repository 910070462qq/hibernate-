package top.miaodou.hibernate.Utils;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.Customer.Customer;

public class HibernateDemo02 {

	@Test
	//保存客户
	public void dem01(){
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
	
		Customer customer = new Customer();
		customer.setCust_name("二狗子");
		session.save(customer);
		
		tx.commit();
		session.close();
	
	}
	
	@Test
	public void demo02(){
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		
//		//使用get方法查询
//		Customer customer = session.get(Customer.class, 1l);
//		System.out.println(customer);
		
		//使用load方法查询
		Customer customer = session.load(Customer.class,2l);
		System.out.println(customer);
		
		tx.commit();
		session.close();
		
	}
	//-----------------------------------------------
	
	@Test
	//修改
	public void demo03(){
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		
		//直接创建对象，进行修改
//		Customer customer = new Customer();
//		customer.setCust_id(1l);
//		customer.setCust_name("赵六");
//		session.update(customer);
		
		//先查询，再修改
		Customer customer = session.get(Customer.class, 1l);
		customer.setCust_name("王小贱");
		session.update(customer);
		
		
		tx.commit();
		session.close();
	}
	
	//删除
	@Test
	public void demo04(){
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		
		//直接创建对象，删除
//		Customer customer = new Customer();
//		customer.setCust_id(1l);
//		session.delete(customer);
		
		//先查询，在删除
		Customer customer2 = session.get(Customer.class, 2l);
		session.delete(customer2);
		
		tx.commit();
		session.close();
	}
	
	//查询所有
	@Test
	public void demo05(){
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		
		//接收HQL: Hibernate Query Language 面向对象语言查询
//		Query query = session.createQuery("from Customer");		
//		List<Customer> list = query.list();
//		for (Customer customer : list) {
//			System.out.println(customer);
//		}
		//接收SQL
		SQLQuery query = session.createSQLQuery("select * from cst_customer");
		List<Object[]> list = query.list();
		for (Object[] object : list) {
			System.out.println(Arrays.toString( object));
		}
		
		
		tx.commit();
		session.close();
	}
	
	
	
	
	
}
