package top.miaodou.dao;

import top.miaodou.domain.User;

/**
 * 用户DAO的接口
 * */
public interface UserDao {

	User login(User user);

}
