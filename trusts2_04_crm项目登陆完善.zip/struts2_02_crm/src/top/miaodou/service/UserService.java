package top.miaodou.service;

import top.miaodou.domain.User;
/**
 * 用户的业务层的接口
 * */
public interface UserService {

	User login(User user);

}
