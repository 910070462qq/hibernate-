package top.miaodou.service.impl;

import top.miaodou.dao.UserDao;
import top.miaodou.dao.impl.UserDaoImpl;
import top.miaodou.domain.User;
import top.miaodou.service.UserService;
/**
 * 用户的业务层的实现类
 * */
public class UserServiceImpl implements UserService {

	/**
	 * 业务层用户登录的方法
	 * */
	public User login(User user) {
		UserDao userDao = new UserDaoImpl();
		return userDao.login(user);
	}

}
