package top.miaodou.web.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import top.miaodou.domain.Customer;
import top.miaodou.service.CustomerService;
import top.miaodou.service.impl.CustomerServiceImpl;

/**
 * 客户管理的Action
 * */
public class CustomerAction extends ActionSupport implements ModelDriven<Customer>{
	
	//模型驱动使用的对象
	private Customer customer = new Customer();
	public Customer getModel() {

		return customer;
	}
	
	//查询客户列表的方法
	public String find(){
		//调用业务层
		CustomerService service = new CustomerServiceImpl();
		List<Customer> list = service.find();		
		//页面跳转
//		ServletActionContext.getRequest().setAttribute("list", list);
		
		//将查询到的list存入到值栈中
		ActionContext.getContext().getValueStack().set("list", list);
		
		
		return "findSuccess";
	}
	
	
	/**
	 * 跳转到添加页面的方法
	 * */
	public String saveUI(){
		
		return "saveUI";
	}
	
	/**
	 * 保存客户的方法
	 * */
	public String save(){
		//接收数据
		//封装数据---这两项模型驱动已经完成
		//调用业务层
		CustomerService service = new CustomerServiceImpl();
		service.save(customer);
		
		//页面跳转
		return "saveSuccess";
	}



}
