package top.miaodou.web.action;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import top.miaodou.domain.User;
import top.miaodou.service.UserService;
import top.miaodou.service.impl.UserServiceImpl;

/**
 * 用户的Action类
 * */
public class UserAction extends ActionSupport implements ModelDriven<User>{
	//接收数据
	private User user = new User();
	public User getModel() {	
		return user;
	}
	/**
	 * 用户登录的方法
	 * */
	public String login(){
//		System.out.println(user);
		//调用业务层：
		UserService service = new UserServiceImpl();
		User existUser = service.login(user);
		//根据结果页面跳转
		if(existUser == null){
			//登陆失败
			this.addActionError("用户名或者密码错误！！");
			return LOGIN;
		}else{
			//登陆成功
			ServletActionContext.getRequest().getSession().setAttribute("existUser", existUser);
			return SUCCESS;
		}
	}

}
