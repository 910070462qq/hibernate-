package top.miaodou.Demo01;

/**
 * Struts2的入门的Action类
 * */
public class HelloAction {
	/**
	 * 提供一个方法：
	 * */ 
	
	public String execute(){
		
		System.out.println("HelloAction执行了。。。");
		return "success";
	}
}
