package top.miaodou.Demo02;
/**
 * ACtion的编写方式：Action类是一个POJO的类
 * */
public class ActionDemo1 {
	public String execute(){
		System.out.println("Action执行了。。。。");
		return null;
	}
}
