package top.miaodou.service.Impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import top.miaodou.dao.CustomerDao;
import top.miaodou.domain.Customer;
import top.miaodou.service.CustomerService;
/**
 * 客户管理的Service的实现类
 * */

@Service("customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService{

	
	//注入Dao
	@Resource(name="customerDao")
	private CustomerDao customerDao;
	
	@Override
	public void save(Customer customer) {
		System.out.println("Service方法执行了。。。。。。。");
		customerDao.save(customer);
	}

}
