package top.miaodou.service;

import top.miaodou.domain.Customer;

/**
 * 客户管理的Service的接口
 * */
public interface CustomerService {

	void save(Customer customer);

}
