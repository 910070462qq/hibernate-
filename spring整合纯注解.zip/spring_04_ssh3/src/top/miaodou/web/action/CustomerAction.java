package top.miaodou.web.action;



import javax.annotation.Resource;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import top.miaodou.domain.Customer;
import top.miaodou.service.CustomerService;
/**
 * 将Action交给Spring管理
 * 
 * */
@Controller("customerAction")
@Scope("prototype")
@ParentPackage("struts-default")
@Namespace("/")
public class CustomerAction extends ActionSupport implements ModelDriven<Customer> {

	private Customer customer = new Customer();
	@Override
	public Customer getModel() {
		return customer;
	}
	
	//注入Service
	@Resource(name="customerService")
	private CustomerService customerService;
	
	@Action(value="customer_save",results={@Result(name="success",location="/login.jsp")})
	public String save(){
		System.out.println("save执行了。。。。。。。。。");
		customerService.save(customer);
		return NONE;
	}
	
}
