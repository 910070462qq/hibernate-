package top.miaodou.dao.impl;

import javax.annotation.Resource;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import top.miaodou.dao.CustomerDao;
import top.miaodou.domain.Customer;
/**
 * 客户管理的DAO的实现类
 * */
@Repository("customerDao")
public class CustomerDaoImpl  implements CustomerDao {
	
	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void save(Customer customer) {
		System.out.println("DAO中的save方法执行了");
		this.hibernateTemplate.save(customer);
	}

}
