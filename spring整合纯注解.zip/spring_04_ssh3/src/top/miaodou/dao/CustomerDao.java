package top.miaodou.dao;

import top.miaodou.domain.Customer;

/**
 * 客户管理的DAO的接口
 * */
public interface CustomerDao {

	void save(Customer customer);

}
