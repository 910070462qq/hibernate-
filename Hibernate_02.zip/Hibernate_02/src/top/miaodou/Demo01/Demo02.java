package top.miaodou.Demo01;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.hibernate.Utils.HibernateUtils;

/**
 * Hibernate的一级缓存的测试。
 *
 * 
 * */
public class Demo02 {
	//证明一级缓存的存在
	@Test
	public void demo01(){
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		
//		Customer customer1 = session.get(Customer.class, 1l);//发送SQL语句
//		System.out.println(customer1);
//		
//		Customer customer2 = session.get(Customer.class, 1l);//不发送SQL语句
//		System.out.println(customer2);
//		
//		System.out.println(customer1 == customer2);

		Customer customer = session.get(Customer.class, 1l);//发送SQL语句
		customer.setCust_name("啊杰啊");
		Serializable id = session.save(customer);
		
		Customer customer2 = session.get(Customer.class, id);
		System.out.println(customer2);
		
		tx.commit();
		session.close();
	}
	
	
}
