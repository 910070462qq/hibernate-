package top.miaodou.Demo01;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.hibernate.Utils.HibernateUtils;

public class Demo01 {
	
	@Test
	//先保存一条记录
	public void demo01(){
		Session session = HibernateUtils.openSession();
		Transaction transaction = session.beginTransaction();
		
		Customer customer = new Customer();
		customer.setCust_name("李四");
		session.save(customer);
		
		transaction.commit();
		session.close();
	}
	
	
	
	
	
	
	@Test
	//持久态对象自动更新数据
	public void demo02(){
		Session session = HibernateUtils.openSession();
		Transaction transaction = session.beginTransaction();
		
		//获得持久态对象
		Customer customer = session.get(Customer.class, 1l);
		customer.setCust_name("二狗子");
//		session.update(customer);
		
		transaction.commit();
		session.close();
	}
	
	
	

	
	
}
