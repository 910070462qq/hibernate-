package top.miaodou.service.impl;

import java.util.List;

import top.miaodou.dao.CustomerDao;
import top.miaodou.dao.impl.CustomerDaoImpl;
import top.miaodou.domain.Customer;
import top.miaodou.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {

	public List<Customer> find() {
		//调用DAO
		CustomerDao dao = new CustomerDaoImpl();
		
		return dao.find();
	}
	//业务层保存客户的方法
	public void save(Customer customer) {
		//调用DAO
		CustomerDao dao = new CustomerDaoImpl();
		dao.save(customer);
	}

}
