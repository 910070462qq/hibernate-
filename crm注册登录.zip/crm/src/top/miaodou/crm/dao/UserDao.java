package top.miaodou.crm.dao;

import top.miaodou.crm.domain.User;

public interface UserDao {

	void save(User user);

	User login(User user);

}
