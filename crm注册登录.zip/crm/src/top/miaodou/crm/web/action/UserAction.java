package top.miaodou.crm.web.action;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
 
import top.miaodou.crm.domain.User;
import top.miaodou.crm.service.UserService;

/**
 * 用户管理的Action的类
 * */
public class UserAction extends ActionSupport implements ModelDriven<User>{
	//模型驱动使用的对象
	private User user = new User();
	@Override
	public User getModel() {
		return user;
	}	
	//注入Service：
	private UserService userService;
	
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	/**
	 * 用户注册的方法
	 * */
	public String regist(){
		userService.regist(user);	
		return LOGIN;
	}
	                     
	/**
	 * 用户登录的方法：login
	 * */
	public String login(){
		 
		//调用业务层查询用户
		User exisUser =  userService.login(user);
		
		if(exisUser == null){
			//登录失败
			//添加错误信息
			this.addActionError("用户名或密码错误！");
			return LOGIN;
		}else{
			//登录成功
//			ServletActionContext.getRequest().getSession().setAttribute("exisUser", exisUser);
			ActionContext.getContext().getSession().put("exisUser", exisUser);
			return SUCCESS;
		}
		
		
	}
}
