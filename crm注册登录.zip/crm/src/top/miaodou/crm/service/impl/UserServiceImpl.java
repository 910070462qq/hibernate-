 package top.miaodou.crm.service.impl;

import org.springframework.transaction.annotation.Transactional;

import top.miaodou.crm.Utils.MD5Utils;
import top.miaodou.crm.dao.UserDao;
import top.miaodou.crm.domain.User;
import top.miaodou.crm.service.UserService;

@Transactional
public class UserServiceImpl implements UserService {
	
//	注入DAO：
	private UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	//业务层注册用户的方法
	public void regist(User user) {
		//对密码进行加密处理
		user.setUser_password(MD5Utils.md5(user.getUser_password()));
		//把用户的状态改为1正常
		user.setUser_state("1");		
		//调用DAO
		userDao.save(user);
	}

	@Override
	//业务层用户登录的
	public User login(User user) {
		
		//登录时密码也需要进行处理
		user.setUser_password(MD5Utils.md5(user.getUser_password()));
		//调用DAO
		return userDao.login(user);
	}
}
