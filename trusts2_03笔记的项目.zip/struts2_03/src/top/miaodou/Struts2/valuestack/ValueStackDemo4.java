package top.miaodou.Struts2.valuestack;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.ValueStack;

import top.miaodou.Struts2.domain.User;
/**
 * 操作ValueStack :方式二：调用值栈当中的方法实现
 * */
public class ValueStackDemo4 extends ActionSupport {

	@Override
	public String execute() throws Exception {
		//向值栈中保存数据
		//获得值栈对象
		ValueStack valueStack = ActionContext.getContext().getValueStack();
		//使用push（Object bobj）;  set(String key,Object obj) 
		User user = new User("二狗子","35");
		//现在User在栈顶的位置
		valueStack.push(user);		
		valueStack.set("name", "张文杰");//创建了一个Map，将Map压入栈中	
		return super.execute();
	}
}
