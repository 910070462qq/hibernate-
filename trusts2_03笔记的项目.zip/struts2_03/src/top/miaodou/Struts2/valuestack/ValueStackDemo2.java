package top.miaodou.Struts2.valuestack;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.ValueStack;
/**
 * 获得ValueStack对象
 * */
public class ValueStackDemo2 extends ActionSupport {
	
	@Override
	public String execute() throws Exception {
		//第一种：获得值栈
		ValueStack valueStack = ActionContext.getContext().getValueStack();
		
		//第二种：通过request对象来获得
		ValueStack valueStack2 = (ValueStack) ServletActionContext.getRequest().getAttribute(ServletActionContext.STRUTS_VALUESTACK_KEY);
		
		//一个Action的实例，只会创建一个ValueStack的对象
		System.out.println(valueStack == valueStack2);
		
		return NONE;
	}
}
