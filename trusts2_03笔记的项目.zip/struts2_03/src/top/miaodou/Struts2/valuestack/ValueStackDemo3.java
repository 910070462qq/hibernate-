package top.miaodou.Struts2.valuestack;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.ValueStack;

import top.miaodou.Struts2.domain.User;
/**
 * 操作ValueStack :方式以：利用Action本身在值栈中的特性来实现
 * */
public class ValueStackDemo3 extends ActionSupport {
	private User user;

	public User getUser() {
		return user;
	}
	@Override
	public String execute() throws Exception {
		//向ValueStack中存值		
		user = new User("李兵","222");	 
		return SUCCESS;
	}
}
