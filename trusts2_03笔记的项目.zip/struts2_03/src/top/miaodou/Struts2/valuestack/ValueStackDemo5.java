package top.miaodou.Struts2.valuestack;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.ValueStack;

import top.miaodou.Struts2.domain.User;
/**
 * 获取值栈的数据
 * */
public class ValueStackDemo5 extends ActionSupport {

	@Override
	public String execute() throws Exception {
		//像值栈中保存一个对象
		User user = new User("aaa","456");
		ActionContext.getContext().getValueStack().push(user);;
		//向值栈中保存一个集合
		List<User> list = new ArrayList<User>();
		list.add(new User("bbb","1111"));
		list.add(new User("ccc","1111"));
		list.add(new User("eee","1111"));
		
		ActionContext.getContext().getValueStack().set("list", list);
		
		//向context中存入数据：
		ServletActionContext.getRequest().setAttribute("name", "王五");
		ServletActionContext.getRequest().getSession().setAttribute("name","s李四");
		ServletActionContext.getServletContext().setAttribute("name", "赵六");
		return super.execute();
	}
}
