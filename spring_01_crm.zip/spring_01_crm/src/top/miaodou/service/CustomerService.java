package top.miaodou.service;

import top.miaodou.domain.Customer;

public interface CustomerService {
	public void save(Customer customer);
 }
