package top.miaodou.service.impl;

import javax.annotation.Resource;

import top.miaodou.dao.CustomerDao;
import top.miaodou.domain.Customer;
import top.miaodou.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {
	//定义一个DAO的属性
	
	private CustomerDao customerDao;
	
	//@Resource(name="customerDao")
	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}


	@Override
	public void save(Customer customer) {
		System.out.println("customer执行力。。。");
		//调用DAO方法
		customerDao.save(customer);
	}
}
