package top.miaodou.web.action;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import top.miaodou.domain.Customer;
import top.miaodou.service.CustomerService;

public class CustomerAction extends ActionSupport implements ModelDriven<Customer>{
	//模型驱动使用的对象
	private Customer customer = new Customer();
	
	@Override
	public Customer getModel() {
		
		return customer;
	}
	/**
	 * 跳转到添加对象的方法：saveUI
	 * */
	public String saveUI(){
		return "saveUI";
	}
	
	/**
	 * 编写保存客户的方法：save
	 * */
	public String save(){
		 //创建一个工厂类
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		CustomerService customerService = (CustomerService) applicationContext.getBean("customerService");
		System.out.println("customerAction方法执行。。。");
		customerService.save(customer);
		return NONE;
	}
}
