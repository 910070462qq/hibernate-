package top.miaodou.dao;

import top.miaodou.domain.Customer;

public interface CustomerDao {
	public void save(Customer customer);
}
