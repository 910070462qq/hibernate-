package top.miaodou.dao.impl;

import top.miaodou.dao.CustomerDao;
import top.miaodou.domain.Customer;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public void save(Customer customer) {
		System.out.println("CustomerDaoImpl执行力。。。");
		
	}

}
