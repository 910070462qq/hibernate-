package top.miaodou.Demo02;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import top.miaodou.domain.Role;
import top.miaodou.domain.User;
import top.miaodou.hibernate.Utils.HibernateUtils;

/**
 * Hibernate的多对多的映射
 * */
public class Demo02 {
	@Test
	/**
	 * 保存多条记录：保存多个用户和角色
	 * */
	public void demo01(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//创建2个用户
		User user1 = new User();
		user1.setUser_code("王五");
		User user2 = new User();
		user2.setUser_code("赵六");
		
		//创建3个角色
		Role role1 = new Role();
		role1.setRole_name("研发部");
		Role role2 = new Role();
		role2.setRole_name("市场部");
		Role role3 = new Role();
		role3.setRole_name("公关部");
		
		//设置双向的关联关系：
		user1.getRoles().add(role1);
		user1.getRoles().add(role2);
		user2.getRoles().add(role2);
		user2.getRoles().add(role3);
		role1.getUsers().add(user1);
		role2.getUsers().add(user1);
		role2.getUsers().add(user2);
		role3.getUsers().add(user2);
		
		// 保存操作:多对多建立了双向的关系必须有一方放弃外键维护。
		// 一般是被动方放弃外键维护权。
		session.save(user1);
		session.save(user2);
		session.save(role1);
		session.save(role2);
		session.save(role3);
		
		tx.commit();
	}
	@Test
	/**
	 * 只保存一边可以不可以，，不行
	 * */
	public void demo02(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//创建2个用户
		User user1 = new User();
		user1.setUser_code("王五");

		
		//创建3个角色
		Role role1 = new Role();
		role1.setRole_name("研发部");
		
		//设置双向的关联关系：
		user1.getRoles().add(role1);
		role1.getUsers().add(user1);

		//只保存用户
		session.save(user1);
		session.save(role1);
		
		tx.commit();
	}
	
	@Test
	/**
	 * 多对多的级联保存：
	 * 保存用户，级联保存角色，在用户的映射文件进行配置
	 * 在User.hbm.xml中的set配置cascade="save-update"
	 * */
	public void demo03(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//创建2个用户
		User user1 = new User();
		user1.setUser_code("王五");

		
		//创建3个角色
		Role role1 = new Role();
		role1.setRole_name("研发部");
		
		//设置双向的关联关系：
		user1.getRoles().add(role1);
		role1.getUsers().add(user1);

		//只保存用户
		session.save(user1);
//		session.save(role1);
		
		tx.commit();
	}
	
	
	@Test
	/**
	 * 多对多的级联保存：
	 * 保存角色级联保存用户，在用户的映射文件进行配置
	 * 在Role.hbm.xml中的set配置cascade="save-update"
	 * */
	public void demo04(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//创建2个用户
		User user1 = new User();
		user1.setUser_code("赵六");

		
		//创建3个角色
		Role role1 = new Role();
		role1.setRole_name("后勤部");
		
		//设置双向的关联关系：
		user1.getRoles().add(role1);
		role1.getUsers().add(user1);

		//只保存用户
//		session.save(user1);
		session.save(role1);
		
		tx.commit();
	}
	
	@Test
	/**
	 * 多对多级联删除：
	 * 删除用户级联删除角色
	 * 在User.hbm.xml中set上配置cascade="delete"
	 * */
	public void demo05(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//查询1号用户
		User user = session.get(User.class, 1l);
		session.delete(user);
		
		tx.commit();
	}
	
	@Test
	/**
	 * 多对多级联删除：
	 * 删除角色级联删除用户
	 * 在Role.hbm.xml中set上配置cascade="delete"
	 * */
	public void demo06(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		//查询3号角色
		Role role = session.get(Role.class,3l);
		session.delete(role);
		
		tx.commit();
	}
	
	/**
	 * 给用户增选角色
	 * */
	@Test
	public void demo07(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		
		//给一号用户多选一个2号角色
		User user = session.get(User.class, 1l);
		Role role = session.get(Role.class, 3l);
		
		user.getRoles().add(role);
		
		
		tx.commit();
	}
	
	
	/**
	 * 给用户改选角色
	 * */
	@Test
	public void demo08(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		
		//给2号用户将原有的3号角色改选为1号角色
		User user = session.get(User.class, 2l);
		Role role = session.get(Role.class, 3l);
		Role role2 = session.get(Role.class, 1l);
		
		user.getRoles().remove(role);
		user.getRoles().add(role2);
		
		
		tx.commit();
	}
	
	/**
	 * 给用户删除角色
	 * */
	@Test
	public void demo09(){
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		
		//给2号用户删除1号角色
		User user = session.get(User.class, 2l);
		Role role = session.get(Role.class, 1l);
		
		user.getRoles().remove(role);

		tx.commit();
	}
}
