package top.miaodou.crm.service;

import org.hibernate.criterion.DetachedCriteria;

import top.miaodou.crm.domain.PageBean;
import top.miaodou.crm.domain.SaleVisit;

/**
 * 客户拜访记录的接口
 * */
public interface SaleVisitService {

	PageBean<SaleVisit> findByPage(DetachedCriteria detachedCriteria, Integer currPage, Integer currSize);

	void save(SaleVisit saleVisit);

}
