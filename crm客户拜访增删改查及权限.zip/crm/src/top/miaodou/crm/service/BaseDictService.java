package top.miaodou.crm.service;

import java.util.List;

import top.miaodou.crm.domain.BaseDict;

/**
 * 字典业务层的接口
 * */
public interface BaseDictService {

	List<BaseDict> finByTypeCode(String dict_type_code);

}
