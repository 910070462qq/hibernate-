package top.miaodou.crm.service;

import org.hibernate.criterion.DetachedCriteria;

import top.miaodou.crm.domain.LinkMan;
import top.miaodou.crm.domain.PageBean;

/**
 * 联系人的业务层的接口
 * */
public interface LinkManService {

	PageBean<LinkMan> findAll(DetachedCriteria detachedCriteria, Integer currPage, Integer pageSize);

	void save(LinkMan linkMan);

	LinkMan findById(Long lkm_id);

	void update(LinkMan linkMan);

	void delete(LinkMan linkMan);

}
