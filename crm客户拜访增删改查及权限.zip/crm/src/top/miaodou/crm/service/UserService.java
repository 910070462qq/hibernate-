package top.miaodou.crm.service;

import java.util.List;

import top.miaodou.crm.domain.User;

public interface UserService {

	void regist(User user);

	User login(User user);

	List<User> findAll();

}
