package top.miaodou.crm.dao;

import top.miaodou.crm.domain.SaleVisit;

public interface SaleVisitDao extends BaseDao<SaleVisit>{

}
