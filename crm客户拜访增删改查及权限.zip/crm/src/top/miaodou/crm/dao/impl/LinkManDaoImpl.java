package top.miaodou.crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.crm.dao.BaseDao;
import top.miaodou.crm.dao.LinkManDao;
import top.miaodou.crm.domain.Customer;
import top.miaodou.crm.domain.LinkMan;
/**
 * 联系人的DAO的实现类
 * */
public class LinkManDaoImpl extends BaseDaoimpl<LinkMan> implements LinkManDao {


}
