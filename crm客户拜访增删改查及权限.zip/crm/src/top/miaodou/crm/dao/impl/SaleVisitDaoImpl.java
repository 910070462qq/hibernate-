package top.miaodou.crm.dao.impl;

import java.io.Serializable;

import top.miaodou.crm.dao.SaleVisitDao;
import top.miaodou.crm.domain.SaleVisit;
/**
 * 客户拜访记录的DAO的实现类
 * */
public class SaleVisitDaoImpl extends BaseDaoimpl<SaleVisit> implements SaleVisitDao {

	
}
