package top.miaodou.crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import top.miaodou.crm.dao.CustomerDao;
import top.miaodou.crm.domain.Customer;
/**
 * 客户管理的DAO的实现类
 * */
public class CustomerDaoImpl extends BaseDaoimpl<Customer> implements CustomerDao {


}
