package top.miaodou.crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import top.miaodou.crm.domain.Customer;

/**
 * 客户管理的DAO
 * */
public interface CustomerDao extends BaseDao<Customer>{

}
