package top.miaodou.crm.dao;

import top.miaodou.crm.domain.User;

public interface UserDao extends BaseDao<User>{


	User login(User user);

}
