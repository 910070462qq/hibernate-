package top.miaodou.Demo;

import com.opensymphony.xwork2.ActionSupport;
/**
 * 数据的校验：
 * 		继承ActionSupport之后才会有一些功能：数据校验、国际化、设置错误信息！
 * */
public class LoginAction2 extends ActionSupport{
	private String username;
	private String password;
	

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	@Override
	public String execute() throws Exception {
		System.out.println(username);
		System.out.println(password);
		
		return NONE;
	}

	
}
