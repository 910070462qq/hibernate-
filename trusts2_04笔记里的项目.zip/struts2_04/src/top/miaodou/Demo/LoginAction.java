package top.miaodou.Demo;

import com.opensymphony.xwork2.ActionSupport;
/**
 * 数据的校验：
 * 		继承ActionSupport之后才会有一些功能：数据校验、国际化、设置错误信息！
 * */
public class LoginAction extends ActionSupport{
	private String username;
	private String password;
	

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String execute() throws Exception {
		
		return NONE;
	}
	//数据校验的方法：
	@Override
	public void validate() {
		//判断用户名不能为空
		if(username == null || username.trim().length() == 0){
			//阻止execute方法执行。
			this.addFieldError("username", "用户名不呢为空");
		}
		if(password == null || password.trim().length() == 0){
			this.addFieldError("password", "密码不能为空。。");
		}
		
	}
	
	//针对一个方法的校验
	public void validateExecute(){
		if(password.length()<6 || password.length() > 12);
		this.addFieldError("password", "你的密码需要在6-12位之间");
	}
	
}
