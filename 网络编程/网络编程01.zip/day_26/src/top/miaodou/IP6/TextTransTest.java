package top.miaodou.IP6;

public class TextTransTest {

	public static void main(String[] args) {
		/**
		 * 客户端输入字母数据，发送给服务端
		 * 服务端收到后显示在控制台，并将该数据转成大写返回给客户端
		 * 直到客户输入over，转换结束
		 * 
		 * 创建一个英文大写转换服务器
		 * 
		 * 分析：
		 * 有客户端和服务端，使用tcp传输
		 */
		
	}
}
