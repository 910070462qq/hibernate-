package top.miaodou.IP4;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Send implements Runnable{
	
	private DatagramSocket ds;
	
	public Send(DatagramSocket ds) {
		this.ds = ds;
	}

	@Override
	public void run() {
		System.out.println("发送请求");
		try {
			BufferedReader bufr = new BufferedReader(new InputStreamReader(System.in));
			
			String line = null;
				while((line = bufr.readLine()) != null){
				
					if("over".equals(line)){
						break;
					}
					
				byte[] buf = line.getBytes();
				
				DatagramPacket dp = 
				new DatagramPacket(buf, buf.length, InetAddress.getByName("192.168.0.113"), 18887);
				
				//3.通过udp的socket服务将数据包发送出去。使用send方法。
				ds.send(dp);
			}
			ds.close();
		} catch (Exception e) {
			
		}
		
	}

}
