package top.miaodou.Demo1;
/**
 * 用户管理业务层接口
 * */
public interface UserService {
	public void save();
}
