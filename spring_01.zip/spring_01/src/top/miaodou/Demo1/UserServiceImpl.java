package top.miaodou.Demo1;
/**
 * 用户管理业务层实现类
 * */
public class UserServiceImpl implements UserService {
	
	private String name;
	
	public void setName(String name) {
		this.name = name;
	}

	public void save() {
		System.out.println("userservice执行了。。"+name);
	}
}
