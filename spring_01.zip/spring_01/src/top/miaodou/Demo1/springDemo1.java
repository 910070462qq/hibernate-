package top.miaodou.Demo1;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * spring入门
 * */
public class springDemo1 {
	
	@Test
	/**
	 * 传统方法的调用
	 * */
	public void demo1(){
		UserService service = new UserServiceImpl();
		service.save();
		
	}
	
	@Test
	/**
	 * Spring方式的调用
	 * */
	public void demo2(){
		//创建Spring的工厂
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		//调用实现类的id，返回userService的实例
		UserService service = (UserService) applicationContext.getBean("userService");
		service.save();
	}
	
	@Test
	/**
	 *加载磁盘上的配置文件 
	 * */
	public void demo3(){
		ApplicationContext applicationContext = new FileSystemXmlApplicationContext("C:\\applicationContext.xml");
		UserService service = (UserService) applicationContext.getBean("userService");
		service.save();
	}
}
