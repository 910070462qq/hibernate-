package top.miaodou.demo3;

public class Car {
	private String name;
	private int car;
	
	public Car() {
		super();
	}
	public Car(String name, int car) {
		super();
		this.name = name;
		this.car = car;
	}
	@Override
	public String toString() {
		return "Car [name=" + name + ", car=" + car + "]";
	}
	

}
