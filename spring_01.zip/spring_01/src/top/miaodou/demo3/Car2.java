package top.miaodou.demo3;

public class Car2 {
	private String name;
	private int car;
	public void setName(String name) {
		this.name = name;
	}
	public void setCar(int car) {
		this.car = car;
	}
	@Override
	public String toString() {
		return "Car2 [name=" + name + ", car=" + car + "]";
	}
	
	
	

}
