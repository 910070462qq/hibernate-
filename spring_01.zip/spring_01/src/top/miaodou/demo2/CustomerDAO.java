package top.miaodou.demo2;

public interface CustomerDAO {
	public void save();
}
