package top.miaodou.demo2;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * spring入门
 * */
public class springDemo2 {
	
	@Test
	/**
	 * 传统方法的调用
	 * */
	public void demo1(){
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		CustomerDAO customer = (CustomerDAO) applicationContext.getBean("customerDAO");
		customer.save();
		applicationContext.close();
	}
	
	
	@Test
	/**
	 * 传统方法的调用
	 * */
	public void demo2(){
	ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
	CustomerDAO customer1 = (CustomerDAO) applicationContext.getBean("customerDAO");
	CustomerDAO customer2 = (CustomerDAO) applicationContext.getBean("customerDAO");	
	System.out.println(customer1 == customer2);
	applicationContext.close();
	
	}
}
