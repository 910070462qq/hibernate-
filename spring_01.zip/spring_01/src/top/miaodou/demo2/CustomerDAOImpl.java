package top.miaodou.demo2;

public class CustomerDAOImpl implements CustomerDAO {

	public void setup(){
		System.out.println("setup初始化执行。。。");
		
	}
	
	public void save() {
		System.out.println("Customer的save方法执行了。。。");
	}
	
	public void destroy(){
		System.out.println("setup被销毁了。。。");
		
	}
	
	
}
