package top.miaodou.redis;

import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class jedisTest {

	@Test
	public void testJedis1()throws Exception{
		//创建和redis的链接
		Jedis jedis = new Jedis("192.168.93.88", 6379);
		
		//存入
		jedis.set("key2", "2");
		//取出
		System.out.println(jedis.get("key2"));
		
		//关闭连接
		jedis.close();
	}
	
	@Test
	public void testJedisPool()throws Exception{
		//创建和redis的链接
		JedisPool pool = new JedisPool("192.168.93.88", 6379);
		
		//获取链接
		Jedis jedis = pool.getResource();
		
		//存入
		jedis.set("key3", "aaa");
		
		//取出
		System.out.println(jedis.get("key3"));
		//关闭连接,关闭后连接会自动回到连接池，，不关闭连接，连接池耗尽时会死机
		jedis.close();
	}
	
	
	
	
}
