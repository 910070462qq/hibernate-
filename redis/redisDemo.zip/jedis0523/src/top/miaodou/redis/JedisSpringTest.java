package top.miaodou.redis;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class JedisSpringTest {

	private ApplicationContext applicationContext;
	
	public void setup() throws Exception{
		
		applicationContext = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");	
	
	}
	
	@Test
	public void testJedisSpring() throws Exception{
		//获取连接池
		JedisPool jedisPool = (JedisPool) applicationContext.getBean("jedisPool");
		//获取链接
		Jedis jedis = jedisPool.getResource();
		
		//存入
		jedis.set("key4", "bbbb");
		
		//取出
		System.out.println(jedis.get("key4"));
			
	}
	
	
}
