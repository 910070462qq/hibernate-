package top.miaodou.web.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import top.miaodou.domain.Customer;
import top.miaodou.service.CustomerService;
import top.miaodou.service.impl.CustomerServiceImpl;

public class CustomerAction extends ActionSupport{
	public String find(){
		//调用业务层
		CustomerService service = new CustomerServiceImpl();
		List<Customer> list = service.find();
		
		//页面跳转
		ServletActionContext.getRequest().setAttribute("list", list);
		
		
		return "findSuccess";
	}
}
