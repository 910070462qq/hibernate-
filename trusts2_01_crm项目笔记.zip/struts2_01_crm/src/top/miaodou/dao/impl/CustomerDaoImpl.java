package top.miaodou.dao.impl;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;

import top.miaodou.dao.CustomerDao;
import top.miaodou.domain.Customer;
import top.miaodou.utils.HibernateUtils;

public class CustomerDaoImpl implements CustomerDao {

	public List<Customer> find() {
		Session session = HibernateUtils.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		List<Customer> list = session.createQuery("from Customer").list();
		
		tx.commit();
		
		return list;
	}

}
