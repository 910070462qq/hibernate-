package top.miaodou.service;

import java.util.List;

import top.miaodou.domain.Customer;

public interface CustomerService {
	public List<Customer> find();
}
